package com.example.xioptimizer

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tweaks", Context.MODE_PRIVATE)
        val ui = UiSettings(getSharedPreferences("ui", Context.MODE_PRIVATE))
        setContent {
            AppTheme(ui) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val scope = rememberCoroutineScope()
                    val state = remember { AppState(prefs, scope) }
                    App(state, ui)
                }
            }
        }
    }
}

@Composable
fun App(state: AppState, ui: UiSettings) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Главная", "Функции", "Приложения", "Вид")

    LaunchedEffect(Unit) {
        while (true) {
            state.refreshShizuku()
            delay(2000)
        }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, title ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = { Text(title, maxLines = 1) }
                )
            }
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeTab(state, ui)
                1 -> FunctionsTab(state, ui)
                2 -> AppsTab(state, ui)
                else -> LookTab(ui)
            }
        }
        if (state.log.isNotBlank()) {
            Card(Modifier.fillMaxWidth().padding(8.dp)) {
                Row(Modifier.padding(start = 12.dp)) {
                    Text(
                        state.log,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(max = 140.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 12.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { state.clearLog() }) { Text("✕") }
                }
            }
        }
    }
}

// ---------- Общие элементы ----------

@Composable
fun ShizukuCard(state: AppState) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (state.shizukuReady) {
                Text("Shizuku: доступ есть ✅")
            } else {
                Text(
                    if (Shell.isRunning()) "Shizuku запущен, нужно разрешение."
                    else "Shizuku не запущен. Установи его и запусти через отладку по Wi-Fi."
                )
                Button(onClick = { Shell.requestPermission() }) { Text("Дать доступ") }
            }
        }
    }
}

@Composable
fun SwitchCard(
    title: String,
    description: String,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(description, style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = checked, enabled = enabled, onCheckedChange = onChange)
        }
    }
}

@Composable
fun ChoiceRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            if (i == selected) {
                Button(
                    onClick = { onSelect(i) },
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) { Text(label, maxLines = 1) }
            } else {
                OutlinedButton(
                    onClick = { onSelect(i) },
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) { Text(label, maxLines = 1) }
            }
        }
    }
}

// ---------- Вкладка «Функции» ----------

@Composable
fun FunctionsTab(state: AppState, ui: UiSettings) {
    val haptic = LocalHapticFeedback.current
    var animScale by remember { mutableFloatStateOf(1f) }
    val canRun = state.shizukuReady && !state.busy

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ShizukuCard(state) }

        item {
            SwitchCard(
                title = "Режим «на свой риск»",
                description = "Показывает агрессивные твики. Они могут вызвать нестабильность, перегрев или потерю функций. Каждый можно откатить выключателем. Включая, ты принимаешь риск на себя.",
                checked = ui.riskUnlocked,
                onChange = { ui.updateRiskUnlocked(it) }
            )
        }

        items(Tweaks.toggles.filter { !it.risky || ui.riskUnlocked }) { tweak ->
            SwitchCard(
                title = (if (tweak.risky) "⚠ " else "") + tweak.title,
                description = tweak.description,
                checked = state.enabled[tweak.id] == true,
                enabled = canRun,
                onChange = { on ->
                    if (ui.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    state.setTweak(tweak, on)
                }
            )
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Свой масштаб анимаций", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "x" + String.format(Locale.US, "%.2f", animScale) +
                            "  (0 = без анимаций, 1 = стандарт)",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Slider(
                        value = animScale,
                        onValueChange = { animScale = it },
                        valueRange = 0f..2f
                    )
                    Button(enabled = canRun, onClick = { state.setAnimScale(animScale) }) {
                        Text("Применить")
                    }
                }
            }
        }

        item { Text("Действия", style = MaterialTheme.typography.titleMedium) }

        items(Tweaks.actions) { action ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(action.title, style = MaterialTheme.typography.titleSmall)
                    Text(action.description, style = MaterialTheme.typography.bodySmall)
                    Button(
                        enabled = canRun,
                        onClick = { state.run(action.title, action.commands, action.quiet) }
                    ) { Text("Запустить") }
                }
            }
        }
    }
}
